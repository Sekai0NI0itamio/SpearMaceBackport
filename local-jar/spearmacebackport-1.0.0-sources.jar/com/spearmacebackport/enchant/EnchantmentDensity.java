package com.spearmacebackport.enchant;

import com.spearmacebackport.SpearMaceBackportMod;
import com.spearmacebackport.item.ItemMace;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.item.ItemStack;

import net.minecraft.enchantment.Enchantment.Rarity;

/** Modern Density: +1 smash damage per fallen block per level. Max 5, table-available. */
public class EnchantmentDensity extends Enchantment {
    public EnchantmentDensity() {
        super(Rarity.COMMON, EnumEnchantmentType.WEAPON, ModEnchants.hand());
        setRegistryName(SpearMaceBackportMod.MOD_ID, "density");
        func_77322_b(SpearMaceBackportMod.MOD_ID + ".density");
    }

    @Override
    public int func_77325_b() {
        return 5;
    }

    @Override
    public int func_77321_a(int level) {
        return 1 + (level - 1) * 8;
    }

    @Override
    public int func_77317_b(int level) {
        return func_77321_a(level) + 20;
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemMace;
    }
}
