package com.spearmacebackport.enchant;

import com.spearmacebackport.SpearMaceBackportMod;
import com.spearmacebackport.item.ItemMace;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.item.ItemStack;

import net.minecraft.enchantment.Enchantment.Rarity;

/** Modern Breach: -15% armor effectiveness per level. Max 4, table-available. */
public class EnchantmentBreach extends Enchantment {
    public EnchantmentBreach() {
        super(Rarity.RARE, EnumEnchantmentType.WEAPON, ModEnchants.hand());
        setRegistryName(SpearMaceBackportMod.MOD_ID, "breach");
        func_77322_b(SpearMaceBackportMod.MOD_ID + ".breach");
    }

    @Override
    public int func_77325_b() {
        return 4;
    }

    @Override
    public int func_77321_a(int level) {
        return 15 + (level - 1) * 9;
    }

    @Override
    public int func_77317_b(int level) {
        return func_77321_a(level) + 20;
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemMace;
    }
}
