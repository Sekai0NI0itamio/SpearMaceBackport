package com.spearmacebackport.enchant;

import com.spearmacebackport.SpearMaceBackportMod;
import com.spearmacebackport.item.ItemDiamondSpear;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.item.ItemStack;

import net.minecraft.enchantment.Enchantment.Rarity;

/** Modern Lunge: boosts spear charge (sprint/velocity) damage. Max 3, table-available on spears. */
public class EnchantmentLunge extends Enchantment {
    public EnchantmentLunge() {
        super(Rarity.UNCOMMON, EnumEnchantmentType.WEAPON, ModEnchants.hand());
        setRegistryName(SpearMaceBackportMod.MOD_ID, "lunge");
        func_77322_b(SpearMaceBackportMod.MOD_ID + ".lunge");
    }

    @Override
    public int func_77325_b() {
        return 3;
    }

    @Override
    public int func_77321_a(int level) {
        return 5 + (level - 1) * 8;
    }

    @Override
    public int func_77317_b(int level) {
        return func_77321_a(level) + 20;
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemDiamondSpear;
    }
}
