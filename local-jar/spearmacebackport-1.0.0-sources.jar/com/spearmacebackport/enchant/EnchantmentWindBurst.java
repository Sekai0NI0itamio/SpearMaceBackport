package com.spearmacebackport.enchant;

import com.spearmacebackport.SpearMaceBackportMod;
import com.spearmacebackport.item.ItemMace;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnumEnchantmentType;
import net.minecraft.item.ItemStack;

import net.minecraft.enchantment.Enchantment.Rarity;

/** Modern Wind Burst: smash launches the attacker upward for chained smashes. Max 3, treasure-only. */
public class EnchantmentWindBurst extends Enchantment {
    public EnchantmentWindBurst() {
        super(Rarity.VERY_RARE, EnumEnchantmentType.WEAPON, ModEnchants.hand());
        setRegistryName(SpearMaceBackportMod.MOD_ID, "wind_burst");
        func_77322_b(SpearMaceBackportMod.MOD_ID + ".wind_burst");
    }

    @Override
    public int func_77325_b() {
        return 3;
    }

    @Override
    public int func_77321_a(int level) {
        return 20 + (level - 1) * 10;
    }

    @Override
    public int func_77317_b(int level) {
        return func_77321_a(level) + 15;
    }

    @Override
    public boolean func_185261_e() {
        return true;
    }

    @Override
    public boolean func_92089_a(ItemStack stack) {
        return stack.func_77973_b() instanceof ItemMace;
    }
}
