package com.spearmacebackport.combat;

import com.spearmacebackport.SpearMaceBackportMod;
import com.spearmacebackport.enchant.ModEnchants;
import com.spearmacebackport.item.ItemDiamondSpear;
import com.spearmacebackport.item.ItemMace;
import com.spearmacebackport.item.ModItems;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.DamageSource;
import net.minecraft.util.CombatRules;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.storage.loot.LootEntryItem;
import net.minecraft.world.storage.loot.LootPool;
import net.minecraft.world.storage.loot.RandomValueRange;
import net.minecraft.world.storage.loot.conditions.LootCondition;
import net.minecraft.world.storage.loot.functions.LootFunction;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.item.Item;
import net.minecraftforge.event.AnvilUpdateEvent;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Modern combat backport core.
 * Mace smash: +3 damage per fallen block (scaled by 1.12 attack cooldown),
 * Density +1/block/level, Breach +15% smash damage/level (1.12 armor-model
 * approximation), Wind Burst vertical launch, smash negates accumulated fall.
 * Spear: 2-4.5 reach jab on right-click, sprint charge scaling, Lunge bonus,
 * soft sub-2-block dead zone. Easy-swap: a sword hit followed by a mace
 * smash within 1.0s applies BOTH hits without vanilla attribute swapping.
 */
@Mod.EventBusSubscriber(modid = SpearMaceBackportMod.MOD_ID)
public class CombatHandler {
    public static final long SWAP_WINDOW_MS = 1000L;
    private static final double SMASH_PER_BLOCK = 3.0D;
    private static final double DENSITY_PER_BLOCK = 1.0D;
    private static final double BREACH_FRACTION_PER_LEVEL = 0.15D;

    private static final Map<UUID, SwapMemory> LAST_SWORD_HIT = new HashMap<>();
    private static final Map<UUID, Long> LAST_SMASH_MS = new HashMap<>();

    private static final class SwapMemory {
        final long timeMs;
        final float damage;
        final int victimId;

        SwapMemory(long timeMs, float damage, int victimId) {
            this.timeMs = timeMs;
            this.damage = damage;
            this.victimId = victimId;
        }
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (event.getEntityLiving() == null || event.getEntityLiving().field_70170_p.field_72995_K) {
            return;
        }
        if (!(event.getSource().func_76346_g() instanceof EntityPlayer)) {
            return;
        }
        EntityPlayer attacker = (EntityPlayer) event.getSource().func_76346_g();
        ItemStack held = attacker.func_184614_ca();
        if (held.func_190926_b()) {
            return;
        }

        if (held.func_77973_b() instanceof ItemMace) {
            handleMaceHit(event, attacker, held);
        } else if (held.func_77973_b() instanceof ItemDiamondSpear) {
            handleSpearMelee(event, attacker);
        } else if (held.func_77973_b() instanceof ItemSword) {
            LAST_SWORD_HIT.put(attacker.func_110124_au(),
                    new SwapMemory(System.currentTimeMillis(), event.getAmount(),
                            event.getEntityLiving().func_145782_y()));
        }
    }

    private static void handleMaceHit(LivingHurtEvent event, EntityPlayer attacker, ItemStack held) {
        float strength = attacker.func_184825_o(0.5F);
        if (isSmash(attacker)) {
            float fallen = Math.max(0.0F, attacker.field_70143_R - 1.5F);
            int density = EnchantmentHelper.func_77506_a(ModEnchants.DENSITY, held);
            int breach = EnchantmentHelper.func_77506_a(ModEnchants.BREACH, held);
            int windBurst = EnchantmentHelper.func_77506_a(ModEnchants.WIND_BURST, held);

            double bonus = fallen * (SMASH_PER_BLOCK + DENSITY_PER_BLOCK * density);
            bonus *= strength;
            event.setAmount(event.getAmount() + (float) bonus);
            if (breach > 0) {
                applyBreach(event, attacker, held, breach);
            }

            if (windBurst > 0) {
                attacker.field_70181_x = 0.9D + 0.35D * windBurst;
                attacker.field_70133_I = true;
            }
            attacker.field_70143_R = 0.0F;
            LAST_SMASH_MS.put(attacker.func_110124_au(), System.currentTimeMillis());

            SwapMemory memory = LAST_SWORD_HIT.remove(attacker.func_110124_au());
            if (memory != null
                    && System.currentTimeMillis() - memory.timeMs <= SWAP_WINDOW_MS
                    && memory.victimId == event.getEntityLiving().func_145782_y()) {
                event.setAmount(event.getAmount() + memory.damage);
            }
        }
    }

    /**
     * True Breach semantics: shrink the victim's effective armor by 15% per
     * level, then top up the pre-armor amount so the post-armor result matches
     * a hit against that reduced armor (via vanilla CombatRules).
     */
    private static void applyBreach(LivingHurtEvent event, EntityPlayer attacker,
                                    ItemStack held, int breach) {
        EntityLivingBase victim = event.getEntityLiving();
        float armor = (float) victim.func_70658_aO();
        if (armor <= 0.0F) {
            return;
        }
        float toughness = (float) victim.func_110148_a(
                SharedMonsterAttributes.field_189429_h).func_111126_e();
        float reduced = Math.max(0.0F, armor * (1.0F - (float) BREACH_FRACTION_PER_LEVEL * breach));
        float amount = event.getAmount();
        float want = CombatRules.func_189427_a(amount, reduced, toughness);
        float have = CombatRules.func_189427_a(amount, armor, toughness);
        if (want > have) {
            event.setAmount(amount + (want - have));
        }
    }

    private static boolean isSmash(EntityPlayer attacker) {
        return !attacker.field_70122_E && attacker.field_70143_R > 1.5F && attacker.field_70181_x < 0.0D;
    }

    private static void handleSpearMelee(LivingHurtEvent event, EntityPlayer attacker) {
        double distance = attacker.func_70032_d(event.getEntityLiving());
        if (distance < ItemDiamondSpear.MIN_REACH) {
            event.setAmount(event.getAmount() * 0.25F);
        }
    }

    @SubscribeEvent
    public static void onLivingFall(LivingFallEvent event) {
        if (event.getEntityLiving().field_70170_p.field_72995_K
                || !(event.getEntityLiving() instanceof EntityPlayer)) {
            return;
        }
        EntityPlayer player = (EntityPlayer) event.getEntityLiving();
        Long smashMs = LAST_SMASH_MS.get(player.func_110124_au());
        if (smashMs != null && System.currentTimeMillis() - smashMs < 1000L
                && event.getDistance() < 6.0F) {
            event.setCanceled(true);
            LAST_SMASH_MS.remove(player.func_110124_au());
        }
    }

    @SubscribeEvent
    public static void onSpearJab(PlayerInteractEvent.RightClickItem event) {
        if (event.getWorld().field_72995_K || !(event.getEntityPlayer() instanceof EntityPlayer)) {
            return;
        }
        EntityPlayer player = event.getEntityPlayer();
        ItemStack held = event.getItemStack();
        if (held.func_190926_b() || !(held.func_77973_b() instanceof ItemDiamondSpear)) {
            return;
        }
        if (player.func_184811_cZ().func_185141_a(held.func_77973_b())) {
            return;
        }
        int lunge = EnchantmentHelper.func_77506_a(ModEnchants.LUNGE, held);
        double reach = ItemDiamondSpear.MAX_REACH + lunge * 0.25D;
        reach = Math.min(reach, blockLimitedReach(player, reach));
        EntityLivingBase target = raycastLiving(player, reach);
        if (target == null) {
            return;
        }
        double distance = player.func_70032_d(target);
        float damage = (float) ItemDiamondSpear.BASE_DAMAGE;
        if (distance < ItemDiamondSpear.MIN_REACH) {
            damage *= 0.25F;
        }
        double blocksPerSecond = Math.sqrt(player.field_70159_w * player.field_70159_w
                + player.field_70179_y * player.field_70179_y) * 20.0D;
        if (player.func_70051_ag() || blocksPerSecond > 3.0D) {
            damage += Math.min(6.0F, (float) (blocksPerSecond * 0.35D)) + lunge * 1.5F;
            target.func_70653_a(player, 0.6F + 0.2F * lunge,
                    player.field_70165_t - target.field_70165_t, player.field_70161_v - target.field_70161_v);
        }
        damage += EnchantmentHelper.func_152377_a(held, target.func_70668_bt());
        boolean hurt = target.func_70097_a(DamageSource.func_76365_a(player), damage);
        if (hurt) {
            held.func_77972_a(1, player);
            player.func_184811_cZ().func_185145_a(held.func_77973_b(), 21);
            player.func_184609_a(event.getHand());
        }
        event.setCanceled(true);
    }

    private static double blockLimitedReach(EntityPlayer player, double reach) {
        Vec3d eye = player.func_174824_e(1.0F);
        Vec3d end = eye.func_178787_e(player.func_70676_i(1.0F).func_186678_a(reach));
        net.minecraft.util.math.RayTraceResult hit =
                player.field_70170_p.func_147447_a(eye, end, false, true, false);
        if (hit != null && hit.field_72313_a == net.minecraft.util.math.RayTraceResult.Type.BLOCK) {
            return Math.min(reach, eye.func_72438_d(hit.field_72307_f));
        }
        return reach;
    }

    private static EntityLivingBase raycastLiving(EntityPlayer player, double reach) {
        Vec3d eye = player.func_174824_e(1.0F);
        Vec3d look = player.func_70676_i(1.0F);
        AxisAlignedBB box = player.func_174813_aQ().func_186662_g(reach);
        List<Entity> entities = player.field_70170_p.func_72839_b(player, box);
        EntityLivingBase best = null;
        double bestAlong = Double.MAX_VALUE;
        for (Entity entity : entities) {
            if (!(entity instanceof EntityLivingBase) || !entity.func_70067_L()) {
                continue;
            }
            AxisAlignedBB target = entity.func_174813_aQ();
            Vec3d center = target.func_189972_c();
            Vec3d toTarget = center.func_178788_d(eye);
            double along = toTarget.func_72430_b(look);
            if (along < 0.0D || along > reach) {
                continue;
            }
            Vec3d closest = eye.func_178787_e(look.func_186678_a(along));
            double lateral = closest.func_72438_d(center);
            double allowed = Math.max(target.func_72320_b() * 0.5D + 0.6D, 1.0D);
            if (lateral <= allowed && along < bestAlong) {
                bestAlong = along;
                best = (EntityLivingBase) entity;
            }
        }
        return best;
    }

    @SubscribeEvent
    public static void onAnvil(AnvilUpdateEvent event) {
        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();
        if (left.func_190926_b() || right.func_190926_b()
                || right.func_77973_b() != Items.field_151134_bR) {
            return;
        }
        Map<Enchantment, Integer> book = EnchantmentHelper.func_82781_a(right);
        if (book.isEmpty()) {
            return;
        }
        boolean spear = left.func_77973_b() instanceof ItemDiamondSpear;
        boolean mace = left.func_77973_b() instanceof ItemMace;
        if (!spear && !mace) {
            return;
        }
        ItemStack out = left.func_77946_l();
        Map<Enchantment, Integer> merged = EnchantmentHelper.func_82781_a(left);
        boolean changed = false;
        for (Map.Entry<Enchantment, Integer> entry : book.entrySet()) {
            Enchantment ench = entry.getKey();
            if (ench == null) {
                continue;
            }
            boolean allowed = ench.func_92089_a(left)
                    || (spear && isSpearAnvilEnchant(ench))
                    || (mace && isMaceAnvilEnchant(ench));
            if (allowed) {
                int current = merged.containsKey(ench) ? merged.get(ench) : 0;
                merged.put(ench, Math.min(Math.max(current, entry.getValue()), ench.func_77325_b()));
                changed = true;
            }
        }
        if (changed) {
            EnchantmentHelper.func_82782_a(merged, out);
            event.setOutput(out);
            event.setCost(5);
            event.setMaterialCost(1);
        }
    }

    private static boolean isSpearAnvilEnchant(Enchantment ench) {
        return ench == ModEnchants.LUNGE
                || (ench.getRegistryName() != null
                && (ench.getRegistryName().toString().startsWith("minecraft:sharpness")
                || ench.getRegistryName().toString().startsWith("minecraft:smite")
                || ench.getRegistryName().toString().startsWith("minecraft:bane_of_arthropods")
                || ench.getRegistryName().toString().startsWith("minecraft:fire_aspect")
                || ench.getRegistryName().toString().startsWith("minecraft:looting")
                || ench.getRegistryName().toString().startsWith("minecraft:knockback")
                || ench.getRegistryName().toString().startsWith("minecraft:unbreaking")
                || ench.getRegistryName().toString().startsWith("minecraft:mending")));
    }

    private static boolean isMaceAnvilEnchant(Enchantment ench) {
        return ench == ModEnchants.DENSITY || ench == ModEnchants.BREACH
                || ench == ModEnchants.WIND_BURST
                || (ench.getRegistryName() != null
                && (ench.getRegistryName().toString().startsWith("minecraft:smite")
                || ench.getRegistryName().toString().startsWith("minecraft:bane_of_arthropods")
                || ench.getRegistryName().toString().startsWith("minecraft:fire_aspect")
                || ench.getRegistryName().toString().startsWith("minecraft:unbreaking")
                || ench.getRegistryName().toString().startsWith("minecraft:mending")));
    }

    @SubscribeEvent
    public static void onLootLoad(LootTableLoadEvent event) {
        String name = event.getName().toString();
        if (!"minecraft:chests/simple_dungeon".equals(name)
                && !"minecraft:chests/end_city_treasure".equals(name)) {
            return;
        }
        LootPool pool = new LootPool(
                new LootEntryItem[]{
                        new LootEntryItem(ModItems.DIAMOND_SPEAR, 5, 0,
                                new LootFunction[0], new LootCondition[0],
                                SpearMaceBackportMod.MOD_ID + ":diamond_spear"),
                        new LootEntryItem(Items.field_151134_bR, 3, 0,
                                new LootFunction[]{new WindBurstBookFunction()},
                                new LootCondition[0],
                                SpearMaceBackportMod.MOD_ID + ":wind_burst_book")
                },
                new LootCondition[0], new RandomValueRange(0, 1), new RandomValueRange(0),
                SpearMaceBackportMod.MOD_ID + "_loot");
        event.getTable().addPool(pool);
    }

    public static class WindBurstBookFunction extends LootFunction {
        WindBurstBookFunction() {
            super(new LootCondition[0]);
        }

        @Override
        public ItemStack func_186553_a(ItemStack stack, Random rand, net.minecraft.world.storage.loot.LootContext context) {
            NBTTagList stored = new NBTTagList();
            NBTTagCompound tag = new NBTTagCompound();
            tag.func_74777_a("id", (short) Enchantment.func_185258_b(ModEnchants.WIND_BURST));
            tag.func_74777_a("lvl", (short) 1);
            stored.func_74742_a(tag);
            NBTTagCompound root = stack.func_77978_p();
            if (root == null) {
                root = new NBTTagCompound();
                stack.func_77982_d(root);
            }
            root.func_74782_a("StoredEnchantments", stored);
            return stack;
        }
    }
}
