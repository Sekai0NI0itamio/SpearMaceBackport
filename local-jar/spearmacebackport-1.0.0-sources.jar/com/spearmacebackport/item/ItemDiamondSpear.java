package com.spearmacebackport.item;

import com.google.common.collect.Multimap;
import com.spearmacebackport.SpearMaceBackportMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/**
 * Diamond Spear backport (diamond tier only, per request).
 * Modern diamond spear: jab 4 damage, 0.95 attack speed, 1561 durability,
 * 2-4.5 block reach with a sub-2-block dead zone, plus a sprint/velocity
 * charge attack. Reach/charge/dead-zone handled in CombatHandler because
 * 1.12.2 has no attack_range attribute.
 */
public class ItemDiamondSpear extends Item {
    public static final double BASE_DAMAGE = 4.0D;
    public static final double ATTACK_SPEED_MOD = -3.05D;
    public static final double MIN_REACH = 2.0D;
    public static final double MAX_REACH = 4.5D;

    public ItemDiamondSpear() {
        setRegistryName(SpearMaceBackportMod.MOD_ID, "diamond_spear");
        func_77655_b(SpearMaceBackportMod.MOD_ID + ".diamond_spear");
        func_77625_d(1);
        func_77656_e(1561);
        func_77637_a(CreativeTabs.field_78037_j);
        ModItems.ALL.add(this);
    }

    @Override
    public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot slot) {
        Multimap<String, AttributeModifier> map = super.func_111205_h(slot);
        if (ModItems.isMainHand(slot)) {
            // Modifier stacks on the player's base 1.0 attack damage: 3.0 + 1.0 = 4.0.
            map = ModItems.weaponModifiers(BASE_DAMAGE - 1.0D, ATTACK_SPEED_MOD);
        }
        return map;
    }

    @Override
    public boolean func_77644_a(ItemStack stack, net.minecraft.entity.EntityLivingBase target,
                            net.minecraft.entity.EntityLivingBase attacker) {
        stack.func_77972_a(1, attacker);
        return true;
    }

    @Override
    public boolean func_82789_a(ItemStack toRepair, ItemStack repair) {
        return ModItems.repairableWith(toRepair, repair, Items.field_151045_i);
    }
}
